/*
/
/         QTTabBar script sample
/
/					http://qttabbar.wikidot.com/scripting
*/


// Initializes scripting object
var qs = new ActiveXObject( "QTTabBarLib.Scripting" );

qs.Alert( "Now opening \"My Computer\"" );

// Window object
var wnd = qs.OpenWindow( "::{20D04FE0-3AEA-1069-A2D8-08002B30309D}" );

qs.Sleep( 200 );

// TabCollection object
var tabs = wnd.Tabs;

for( var i = 0; i < tabs.Count; i++ )
{
	// Tab object
	var tab = tabs.Item( i );
	qs.Alert( "Tab \"" +  tab.Text + "\" is " + ( tab.Active ? "Active" : "Inactive" ) );
}

// get Active tab
var tabActive = wnd.ActiveTab;
qs.Alert( "The path of active tab is " + tabActive.Path );

var systemDrive = qs.GetFolderPath( "Windows" ).substr( 0, 3 );

qs.Alert( "Now adding a new tab \"" + systemDrive + "\"" );

// adding a new tab to TabCollection object
var tab2 = tabs.Add( systemDrive );

// QCollection object 
var newSel = qs.NewCollection();
newSel.Push( "Program Files" );
newSel.Push( "Windows" );

qs.Alert( "Now selecting \"Program Files\" and \"Windows\" folder" );
// selected file paths in the tab folder view.
tab2.SelectedItems = newSel;

var sel = tab2.SelectedItems;

sel.Sort();

var str = "";
for( var i = 0; i < sel.Count; i++ )
{
	str += sel.Item( i ) + "\n";
}
qs.Alert( "Selected items are\n\n" + str );
